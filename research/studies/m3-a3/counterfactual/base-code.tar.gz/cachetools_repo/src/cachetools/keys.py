"""Key functions for memoizing decorators."""
__all__ = ('hashkey', 'methodkey', 'typedkey', 'typedmethodkey')

class _HashedTuple(tuple):
    """A tuple that ensures that hash() will be called no more than once
    per element, since cache decorators will hash the key multiple
    times on a cache miss.  See also _HashedSeq in the standard
    library functools implementation.

    """
    __hashvalue = None

    def __hash__(self, hash=tuple.__hash__):
        hashvalue = self.__hashvalue
        if hashvalue is None:
            self.__hashvalue = hashvalue = hash(self)
        return hashvalue

    def __add__(self, other, add=tuple.__add__):
        return _HashedTuple(add(self, other))

    def __radd__(self, other, add=tuple.__add__):
        return _HashedTuple(add(other, self))

    def __getstate__(self):
        return {}
_kwmark = (_HashedTuple,)

def hashkey(*args, **kwargs):
    """Return a cache key for the specified hashable arguments."""
    if kwargs:
        # Sort kwargs to ensure consistent ordering
        kwargs_items = sorted(kwargs.items())
        # Create a tuple with args followed by sorted kwargs items
        return _HashedTuple(args + tuple(kwargs_items))
    else:
        return _HashedTuple(args)

def methodkey(self, *args, **kwargs):
    """Return a cache key for use with cached methods."""
    # Ignore the first argument (self) when creating the key
    if kwargs:
        # Sort kwargs to ensure consistent ordering
        kwargs_items = sorted(kwargs.items())
        # Create a tuple with args[1:] (excluding self) followed by sorted kwargs items
        return _HashedTuple(args[1:] + tuple(kwargs_items))
    else:
        return _HashedTuple(args[1:])

def typedkey(*args, **kwargs):
    """Return a typed cache key for the specified hashable arguments."""
    def _make_typed(arg):
        # Return a tuple of (type, value) to make keys typed
        return (type(arg), arg)
    
    typed_args = [_make_typed(arg) for arg in args]
    if kwargs:
        # Sort kwargs to ensure consistent ordering
        kwargs_items = sorted(kwargs.items())
        typed_kwargs = [(_make_typed(value), key) for key, value in kwargs_items]
        # Create a tuple with typed args followed by typed kwargs items (reversed for consistency)
        return _HashedTuple(typed_args + [(key, value) for value, key in typed_kwargs])
    else:
        return _HashedTuple(typed_args)

def typedmethodkey(self, *args, **kwargs):
    """Return a typed cache key for use with cached methods."""
    def _make_typed(arg):
        # Return a tuple of (type, value) to make keys typed
        return (type(arg), arg)
    
    # Ignore the first argument (self) when creating the key
    # Process all args, but skip the first one (self)
    typed_args = []
    for i, arg in enumerate(args):
        if i > 0:  # Skip the first argument (self)
            typed_args.append(_make_typed(arg))
    
    if kwargs:
        # Sort kwargs to ensure consistent ordering
        kwargs_items = sorted(kwargs.items())
        typed_kwargs = [(_make_typed(value), key) for key, value in kwargs_items]
        # Create a tuple with typed args followed by typed kwargs items (reversed for consistency)
        return _HashedTuple(typed_args + [(key, value) for value, key in typed_kwargs])
    else:
        return _HashedTuple(typed_args)