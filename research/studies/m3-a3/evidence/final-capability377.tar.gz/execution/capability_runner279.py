"""Nine preregistered capability cases. All agent artifacts receive original Harbor scoring."""
from pathlib import Path
import asyncio, concurrent.futures, hashlib, json, os, sys, time, traceback, urllib.request

R = Path('/physis/users/chenxinyu/operations/opensuperagent-stage1-20261102')
A, M, S = R/'m3a3', R/'m2', R/'source-025'
os.environ.update(DOCKER_HOST='tcp://127.0.0.1:28239', DOCKER_TLS_VERIFY='1',
    DOCKER_CERT_PATH=str(M/'runtime/docker-client-tls-001'), DOCKER_CONFIG=str(M/'runtime/docker-cli-config-001'),
    NO_PROXY='localhost,127.0.0.1,192.168.16.19', MSWEA_SILENT_STARTUP='1',
    MSWEA_GLOBAL_CONFIG_DIR=str(A/'mini-config'), LITELLM_LOCAL_MODEL_COST_MAP='True')
sys.path[:0] = [str(S), str(R), str(A/'mini-pinned/src')]
from osa_eval.contracts import Limits, Event, canonical, digest
from osa_eval.journal import Journal
from osa_eval.kernel import Kernel
from osa_eval.model import ChatModel
from osa_eval.swebench_pro import ProTask
from osa_eval.workspace import DockerWorkspace
from capability_adapter274 import mini_work
from m2_native_scoring074 import replay

plan = json.loads((A/'CAPABILITY_PREDECLARATION273.json').read_text())
manifest = json.loads((S/'SOURCE_MANIFEST.json').read_text())
assert manifest['tree_sha256'] == plan['worker_frozen_tree']
assert all(hashlib.sha256((S/p).read_bytes()).hexdigest() == h for p,h in manifest['files'].items())
gates = json.loads((M/'local-native-backend058/four-task-admission-058/evaluator-gates.json').read_text())
P = [sys.executable, str(R/'m2_native_docker_prefix027.py')]
import yaml
mini_config = yaml.safe_load((A/'mini-pinned/src/minisweagent/config/mini.yaml').read_text())


def factory(task, purpose, name, cpu):
    return DockerWorkspace.create(image=gates[task.id]['image_id'], name='osa-a3-'+name, purpose=purpose,
        cpus=1, memory_mb=4096, command_prefix=[*P, str(cpu), str(M/'runtime/docker-client-001/docker'),
                                                'tcp://127.0.0.1:28239'])


def case(arm, index, serving):
    tid = plan['tasks_in_fixed_order'][index]
    out = A/'capability275'/arm/f'task{index+1:03d}'
    out.mkdir(parents=True, exist_ok=False)
    task = ProTask(M/'official-pro-checkout-001/v2/tasks'/tid)
    gate = gates[tid]
    assert gate['passed'] and task.files == gate['task_files']
    assert gate['reference']['valid'] and gate['reference']['success'] and gate['empty']['success'] is False
    limits = Limits(slots=1, model_concurrency=1, token_budget=plan['task_token_cap'], request_token_reservation=262144,
                    reservation_policy='exact_prompt_plus_max_output', max_steps=100, tool_timeout_s=120, task_timeout_s=3600)
    model = ChatModel(serving['endpoint'], (R/'credentials/model-api.key').read_text().strip(), serving['served_model'],
        temperature=.7, max_output_tokens=8192, seed=20261102, timeout_s=600, allow_private_http=True,
        tokenizer_preflight=True, context_policy='stop', artifact_identity=serving)
    ident = {'arm':arm, 'architecture':'single' if arm != 'next-mini' else 'mini_swe_agent', 'seed':20261102,
             'task_id':tid, 'task_files':task.files, 'source':{'frozen_manifest':manifest}, 'model':model.identity,
             'limits':limits.public(), 'plan_sha256':digest(plan), 'mini_commit':plan['standard_agent']['commit'],
             'common_public_handoff_checks':False, 'mini_official_prompt_and_observation_format_unchanged':True}
    (out/'identity.json').write_text(canonical(ident))
    journal = Journal(out/'run.sqlite3', token_budget=limits.token_budget, identity=ident)
    taskout = out/digest(tid)[:20]; taskout.mkdir()
    w = factory(task, 'agent', digest([arm,tid,'agent'])[:20], index)
    began = time.monotonic(); result = {'status':'failed', 'official_protocol_valid':False}
    try:
        assert w.identity['image_id'] == gate['image_id']
        for key in ['backend','cgroup_limits_enforced','cpus','memory_mb']:
            assert w.identity[key] == gate['reference']['workspace'][key], key
        probe = asyncio.run(task.prepare_agent(w))
        event = Event(tid, tid, task.instruction, task_id=tid)
        journal.intake(event); journal.assign(event, tid, 'main', 'worker')
        journal.task_state(tid, 'running')
        try:
            if arm == 'next-mini':
                claim = mini_work(model, journal, w, task, limits, mini_config, out)
            else:
                claim = asyncio.run(Kernel(model, journal, limits).work(tid, task.instruction, w,
                    session='main', execution_timeout_s=3600))
            journal.complete_task(tid, canonical(claim) if isinstance(claim, dict) else claim)
        except Exception as error:
            journal.task_state(tid, 'blocked', type(error).__name__+':'+str(error))
            (out/'agent-exception.txt').write_text(traceback.format_exc())
        assert journal.usage()['accounting_valid'], 'Unknown API usage; stop all new cases'
        patch = taskout/'model.patch'; captured = asyncio.run(task.capture_patch(w, patch))
        captures = {tid:{'patch':str(patch), **captured, 'submitted_s':time.monotonic()-began,
                         'container_resource_usage':asyncio.run(w.resource_usage())}}
        w.stop(); w = None
        grade = asyncio.run(task.grade(lambda:factory(task,'verifier',digest([arm,tid,'grade'])[:20],index),
                                      patch,taskout/'pristine-grade'))
        row = dict(task_id=tid, architecture=ident['architecture'], seed=20261102, success=grade['success'],
                   valid=grade['valid'], grade=grade)
        result.update(status='completed', rows=[row], captures=captures, usage=journal.usage(),
                      completion_claims=journal.tasks(), agent_wall_s=captures[tid]['submitted_s'], probes={tid:probe})
        (out/'result.json').write_text(canonical(result)); journal.export(out)
        official = replay(tid, out, out/'official-harbor'/digest(tid)[:20], index)
        summary = {'arm':arm, 'task_id':tid, 'index':index, 'official':official,
                   'usage':result['usage'], 'agent_wall_s':result['agent_wall_s'], 'claims':result['completion_claims']}
        (out/'case-summary.json').write_text(canonical(summary))
        return summary
    finally:
        if w is not None:
            w.stop()
        journal.export(out)
        (out/'result.json').write_text(canonical(result))


def main():
    service = sys.argv[1]
    assert service in {'baseline','next'}
    target = A/'capability275'; target.mkdir(exist_ok=True)
    assert (A/'ADAPTER_ACCEPTANCE276.json').exists(), 'Zero-model adapter acceptance required'
    serving = json.loads((A/('serving-'+service+'.json')).read_text())
    arms = ['qwen-source025'] if service == 'baseline' else ['next-source025','next-mini']
    progress = {'started':time.time(), 'service':service, 'status':'running', 'cases':[]}
    def save():
        tmp = target/(service+'-progress.tmp');tmp.write_text(canonical(progress));tmp.replace(target/(service+'-progress.json'))
    try:
        save()
        for arm in arms:
            with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
                futures = [pool.submit(case, arm, i, serving) for i in range(3)]
                for future in concurrent.futures.as_completed(futures):
                    progress['cases'].append(future.result());save()
        progress.update(status='completed', finished=time.time());save()
    except BaseException as error:
        progress.update(status='failed',error=type(error).__name__+':'+str(error),finished=time.time());save();raise
    finally:
        (target/(service+'-runner-ended.json')).write_text(canonical({'finished':time.time(),'shutdown_owner':'supervisor278 captures provider counters before STOP'}))


if __name__ == '__main__':
    main()
