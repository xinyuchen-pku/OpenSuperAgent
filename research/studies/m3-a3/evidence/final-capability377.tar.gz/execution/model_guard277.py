"""Four verified idle GPUs -> bounded inference -> original reservations and 12 samples.
Never changes a platform job or signals a process whose recorded identity changed.
"""
from pathlib import Path
import fcntl,hashlib,json,os,select,signal,socket,subprocess,time

ROOT=Path('/mnt/datasets/shared-dataset/users/chenxinyu/operations/opensuperagent-stage1-20261102/m3a3-service-baseline277')
OWNER=Path('/mnt/datasets/shared-dataset/users/chenxinyu/operations/openwam_native_alignment_20261027')
GPUS=[0,1,2,3]
GPU_UUIDS=['GPU-f36fc087-95b1-854f-1634-c9206404d0c5','GPU-0f85ebe6-a21a-b4ab-307e-6535fdc48a0e','GPU-4200e0a7-0fb6-3a25-25d4-ba345a57fb43','GPU-5c1fc607-90c1-8298-4524-9c61ceb5dfef']
SOURCE_SHA='711707b1ab422b84f458f2c8ebfdf58d057a9e20bc27bc789303de73164c4846'
PYTHON=Path('/mnt/datasets/shared-dataset/users/chenxinyu/reasoningbank-baseline/envs/vllm-b-cu130-0200-002/bin/python')
MODEL=Path('/mnt/datasets/shared-dataset/users/chenxinyu/reasoningbank-baseline/models/Qwen3-Coder-30B-A3B-Instruct')
COMPAT=Path('/mnt/datasets/shared-dataset/users/chenxinyu/reasoningbank-baseline/cgme_v0/pilots/feedback-state-action-m25-001/runtime/cuda-compat-13-private-001/extracted/usr/local/cuda-13.0/compat')
KEY=Path('/physis/users/chenxinyu/operations/opensuperagent-stage1-20261102/credentials/model-api.key')
ROOT.mkdir(parents=True,exist_ok=True)
TASK_ROOT=Path('/physis/users/chenxinyu/operations/opensuperagent-stage1-20261102');FIRST_STARTED=time.time();SERVICE_DEADLINE=FIRST_STARTED+5400
assert time.time()<SERVICE_DEADLINE-1800, 'Less than30min remains in the original90min cap'
lock=(ROOT/'model-guard.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
state={'time':time.time(),'status':'preflight','gpu_uuids':GPU_UUIDS,'gpu_indices':GPUS,'host':socket.gethostname(),
       'manager_pid':os.getpid(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
       'platform_jobs_modified':False,'training':False,'checkpoint_deletion':False,'model_argv':[]}

def save(**fields):
 state.update(fields,time=time.time());tmp=ROOT/'model-guard.tmp';tmp.write_text(json.dumps(state,indent=2));tmp.replace(ROOT/'model-guard.json')
 mirror=TASK_ROOT/'m3a3/guard277-model-guard.json';temp=mirror.with_suffix('.tmp');temp.write_text(json.dumps(state,indent=2));temp.replace(mirror)
 compat=ROOT/'provider-compatibility.json'
 if compat.exists():
  dest=TASK_ROOT/'m3a3/guard277-provider-compatibility.json';tmpc=dest.with_suffix('.tmp');tmpc.write_bytes(compat.read_bytes());tmpc.replace(dest)

def identity(pid):
 p=Path(f'/proc/{pid}')
 try:
  stat=(p/'stat').read_text().rsplit(')',1)[1].split()
  if stat[0]=='Z':return None
  return {'pid':pid,'start_ticks':stat[19],'argv_sha256':hashlib.sha256((p/'cmdline').read_bytes()).hexdigest()}
 except FileNotFoundError:return None

def exact(record):return identity(record['pid'])==record

def owners(uuid):
 rows=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader,nounits'],text=True).splitlines()
 return {int(r.split(',')[1])for r in rows if r.split(',')[0].strip()==uuid}

def descendants(parent):
 found={parent};previous=None
 while previous!=found:
  previous=set(found)
  for p in Path('/proc').iterdir():
   if not p.name.isdigit():continue
   try:
    fields=(p/'stat').read_text().rsplit(')',1)[1].split()
    if int(fields[1])in found:found.add(int(p.name))
   except (OSError,ValueError):pass
 return [r for pid in found if (r:=identity(pid))]

def signal_exact(record, sig):
 fd=os.pidfd_open(record['pid'])
 try:
  assert exact(record),'Process identity changed; signal refused'
  signal.pidfd_send_signal(fd,sig)
 finally:os.close(fd)

def stop_owned(model_record,tracked):
 if exact(model_record):
  tracked.update({r['pid']:r for r in descendants(model_record['pid'])})
  signal_exact(model_record,signal.SIGTERM)
 deadline=time.time()+60
 while time.time()<deadline and any(exact(r)for r in tracked.values()):time.sleep(1)
 remaining=[r for r in tracked.values()if exact(r)]
 if remaining:
  save(status='owned_shutdown_stalled',verified_remaining_processes=remaining,
       shutdown_action='60s SIGTERM grace elapsed; inspect exact tracked inference descendants, then SIGKILL those same identities')
  for r in remaining:
   if exact(r):signal_exact(r,signal.SIGKILL)
  deadline=time.time()+30
  while time.time()<deadline and any(exact(r)for r in remaining):time.sleep(1)
 assert not any(exact(r)for r in tracked.values()),'Owned processes remain; restoration deferred'

released=[];model_record=None;tracked={};originals={};protected={}
save()
try:
 assert socket.gethostname()=='job-4efk8abez6e7-worker-0'
 hashes=json.loads((ROOT.parent/'m2-model-hashes-001.json').read_text());assert hashes['complete']and hashes['passed']
 fresh=json.loads(Path('/physis/users/chenxinyu/operations/opensuperagent-stage1-20261102/m3/weights-recheck111.json').read_text());assert fresh['complete'] and fresh['passed'] and fresh['manifest_sha256']==hashlib.sha256((ROOT.parent/'m2-model-hashes-001.json').read_bytes()).hexdigest()
 for row in hashes['files']:
  stat=(MODEL/row['path']).stat();assert stat.st_size==row['size']and stat.st_mtime_ns==row['mtime_ns'],'Model file changed after complete hash verification'
 assert hashlib.sha256((OWNER/'reserve.py').read_bytes()).hexdigest()==SOURCE_SHA
 for gpu,uuid in zip(GPUS,GPU_UUIDS):
  binding=json.loads((OWNER/'holder-bindings'/socket.gethostname()/f'gpu{gpu}.json').read_text())
  record=identity(binding['pid']);assert record and record['start_ticks']==binding['start_ticks']
  hp=Path(f'/proc/{record["pid"]}');argv=[x.decode()for x in(hp/'cmdline').read_bytes().split(b'\0')if x]
  assert argv==['/usr/bin/python3',str(OWNER/'reserve.py')]
  env={k.decode():v.decode()for k,v in[x.split(b'=',1)for x in(hp/'environ').read_bytes().split(b'\0')if b'='in x]}
  assert env['CUDA_VISIBLE_DEVICES']==str(gpu)and binding['uuid']==uuid and binding['source_sha256']==SOURCE_SHA
  assert owners(uuid)=={binding['nvml_pid']},'Foreign GPU workload exists'
  originals[gpu]={'identity':record,'argv':argv,'env':env,'cwd':os.readlink(hp/'cwd'),'binding':binding}
 for gpu in range(4,8):protected[str(gpu)]=json.loads((OWNER/'holder-bindings'/socket.gethostname()/f'gpu{gpu}.json').read_text())
 assert KEY.exists()and COMPAT.exists()and PYTHON.exists()
 assert json.loads((TASK_ROOT/'m3a3/ADAPTER_ACCEPTANCE276.json').read_text())['passed']
 probe=socket.socket();probe.bind(('192.168.16.19',18691));probe.close()
 bootstrap=Path('/physis/users/chenxinyu/operations/opensuperagent-stage1-20261102/source-025/osa_eval/vllm_length_priority.py')
 check=subprocess.run([str(PYTHON),str(bootstrap),'--contract-check',str(PYTHON.parent.parent/'lib/python3.12/site-packages/vllm/entrypoints/openai/chat_completion/serving.py')],capture_output=True,text=True,timeout=30);assert check.returncode==0,check.stderr
 save(provider_compatibility_contract=json.loads(check.stdout),bootstrap_sha256=hashlib.sha256(bootstrap.read_bytes()).hexdigest())
 model_argv=[str(PYTHON),str(bootstrap),'--model',str(MODEL),'--served-model-name','osa-qwen3-coder-30b',
  '--host','192.168.16.19','--port','18691','--dtype','bfloat16','--tensor-parallel-size','4','--max-model-len','262144',
  '--max-num-seqs','4','--max-num-batched-tokens','16384','--gpu-memory-utilization','0.90','--enforce-eager',
  '--enable-auto-tool-choice','--tool-call-parser','qwen3_coder','--generation-config','vllm','--seed','20261102','--no-enable-prefix-caching',
  '--override-generation-config',json.dumps({'temperature':0.7,'top_p':0.8,'top_k':20,'repetition_penalty':1.05})]
 save(model_argv=model_argv,model_hash_manifest_sha256=hashlib.sha256((ROOT.parent/'m2-model-hashes-001.json').read_bytes()).hexdigest(),
  protected_original_bindings=protected,original_holders={str(k):v['identity']for k,v in originals.items()},original_holder_source_sha256=SOURCE_SHA,
  budget={'max_service_seconds':max(0,SERVICE_DEADLINE-time.time()),'aggregate_cap_from_first_service_seconds':5400,'model_context':262144,'max_sequences':4,'weights_trainable':False},api_key_reference=str(KEY),status='releasing_verified_holders')
 for gpu in GPUS:
  record=originals[gpu]['identity'];assert exact(record);signal_exact(record,signal.SIGTERM);released.append(gpu)
  deadline=time.time()+45
  while time.time()<deadline and exact(record):time.sleep(.5)
  assert not exact(record),'Original holder did not exit; no inference launched'
 for uuid in GPU_UUIDS:
  deadline=time.time()+30
  while time.time()<deadline and owners(uuid):time.sleep(1)
  assert not owners(uuid),'GPU not empty after verified holder exit'
 env0=originals[0]['env'];env=dict(env0,OSA_VLLM_COMPAT_RECEIPT=str(ROOT/'provider-compatibility.json'),CUDA_VISIBLE_DEVICES='0,1,2,3',LD_LIBRARY_PATH=str(COMPAT)+':'+env0.get('LD_LIBRARY_PATH',''),
  VLLM_API_KEY=KEY.read_text().strip(),VLLM_NO_USAGE_STATS='1',DO_NOT_TRACK='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',
  VLLM_CACHE_ROOT=str(ROOT.parent/'m2-service-003/vllm-cache'),TRITON_CACHE_DIR=str(ROOT.parent/'m2-service-003/triton-cache'),TMPDIR='/tmp/osa-m3a3-baseline277')
 model_cpus=sorted(os.sched_getaffinity(0))[16:48];assert len(model_cpus)==32;save(model_host_cpu_affinity=model_cpus)
 def pin_model():os.sched_setaffinity(0,set(model_cpus))
 Path(env['TMPDIR']).mkdir(exist_ok=True);log=(ROOT/'model-service.log').open('ab');model=subprocess.Popen(model_argv,env=env,stdout=log,stderr=subprocess.STDOUT,preexec_fn=pin_model,start_new_session=True)
 model_record=identity(model.pid);assert model_record;save(status='inference_loading',model_process=model_record,endpoint='http://192.168.16.19:18691/v1')
 deadline=SERVICE_DEADLINE
 while model.poll()is None and time.time()<deadline and not(ROOT/'STOP_MODEL').exists()and not(Path('/physis/users/chenxinyu/operations/opensuperagent-stage1-20261102/m3a3/STOP_BASELINE')).exists():
  tracked.update({r['pid']:r for r in descendants(model.pid)});save(status='inference_process_alive',model_process=model_record,owned_processes=list(tracked.values()))
  try:
   metrics=subprocess.run(['nvidia-smi','--id',','.join(map(str,GPUS)),'--query-gpu=index,uuid,memory.used,utilization.gpu,power.draw','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=3)
   with (ROOT/'gpu-telemetry.jsonl').open('a',encoding='utf-8')as telemetry:telemetry.write(json.dumps({'time':time.time(),'exit':metrics.returncode,'csv':metrics.stdout})+'\n')
  except subprocess.SubprocessError as error:save(telemetry_error=type(error).__name__)
  time.sleep(5)
 save(status='inference_stopping',model_exit=model.poll())
except BaseException as e:save(error=type(e).__name__+':'+str(e),status='failure')
finally:
 try:
  if model_record:stop_owned(model_record,tracked)
  restored={}
  restoration_errors={}
  for gpu in released:
   try:
    old=originals[gpu]
    if exact(old['identity']):continue
    uuid=GPU_UUIDS[GPUS.index(gpu)];deadline=time.time()+30
    while time.time()<deadline and owners(uuid):time.sleep(1)
    assert not owners(uuid),'GPU has another owner; original reservation restoration deferred'
    assert hashlib.sha256((OWNER/'reserve.py').read_bytes()).hexdigest()==SOURCE_SHA
    log=(ROOT/f'restored-reservation-gpu{gpu}.log').open('ab');holder=subprocess.Popen(old['argv'],env=old['env'],cwd=old['cwd'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    restored[str(gpu)]=identity(holder.pid);save(status='restoring_original_reservations',restored_holders=restored)
    (OWNER/'reservations'/socket.gethostname()/f'gpu-{gpu}.pid').write_text(str(holder.pid));deadline=time.time()+150
    while time.time()<deadline:
     try:
      proof=json.loads((OWNER/'occupancy'/socket.gethostname()/f'gpu{gpu}.json').read_text())
      if proof['pid']==holder.pid and proof['state']=='verified'and len(proof['samples'])==12:
       assert all(x['utilization']>0 and x['memory_used']>70000 for x in proof['samples']);(ROOT/f'restoration-proof-gpu{gpu}.json').write_text(json.dumps(proof));break
     except(FileNotFoundError,KeyError,json.JSONDecodeError):pass
     assert holder.poll()is None,'Restored holder exited';time.sleep(1)
    else:raise RuntimeError('Restoration sampling did not pass within150s')
   except BaseException as e:restoration_errors[str(gpu)]=repr(e)
  fresh={str(i):json.loads((OWNER/'holder-bindings'/socket.gethostname()/f'gpu{i}.json').read_text())for i in range(4,8)}
  save(status='restoration_requires_attention'if restoration_errors else('completed_original_reservations_restored'if released else 'preflight_failed_no_gpu_changes'),restored_holders=restored,restoration_errors=restoration_errors,protected_latest_bindings=fresh,protected_gpu_signals_sent=0)
 except BaseException as e:save(status='restoration_requires_attention',restoration_error=repr(e))
