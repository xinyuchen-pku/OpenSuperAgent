from pathlib import Path
import concurrent.futures, json, time
import capability_runner279 as run

A=run.A;O=A/'recovery335';O.mkdir(exist_ok=False)
serving=json.loads((A/'serving-recovery.json').read_text())
prior=json.loads((A/'capability275/next-source025/task002/case-summary.json').read_text())
assert prior['official']['official_protocol_valid']and prior['usage']['accounting_valid']
progress={'started':time.time(),'status':'running','cases':[prior],
          'reused_valid_case':'qutebrowser original first attempt retained unchanged',
          'infrastructure_retries_only':[0,2],'second_infrastructure_failure':'stop; no further retry'}
def save():
    p=O/'progress.tmp';p.write_text(json.dumps(progress,indent=2));p.replace(O/'progress.json')
try:
    save()
    arm='next-source025-recovery335';target=A/'capability275'/arm
    local=Path('/dev/shm/osa-capability-local291')/arm;local.mkdir(exist_ok=False);target.symlink_to(local,target_is_directory=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
        for future in concurrent.futures.as_completed([pool.submit(run.case,arm,i,serving)for i in [0,2]]):
            progress['cases'].append(future.result());save()
    guard=json.loads((A/'guard334-model-guard.json').read_text());launch=json.loads((run.R/'model_guard334.py.launch.json').read_text())
    allowance=guard['budget']['aggregate_cap_from_first_service_seconds']
    assert launch['started']+allowance-time.time()>=3720,'Insufficient remaining GPU cap to admit the full unchanged mini task time allowance'
    with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:
        for future in concurrent.futures.as_completed([pool.submit(run.case,'next-mini',i,serving)for i in range(3)]):
            progress['cases'].append(future.result());save()
    progress.update(status='completed',finished=time.time());save()
except BaseException as error:
    progress.update(status='failed',error=type(error).__name__+':'+str(error),finished=time.time());save();raise
