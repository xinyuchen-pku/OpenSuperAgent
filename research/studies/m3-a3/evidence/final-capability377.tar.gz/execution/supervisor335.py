from pathlib import Path
import hashlib, json, os, subprocess, sys, time, urllib.request
R=Path('/physis/users/chenxinyu/operations/opensuperagent-stage1-20261102');A=R/'m3a3';M=R/'m2'
service=sys.argv[1];guard_id=sys.argv[2];assert service=='recovery'
key=(R/'credentials/model-api.key').read_text().strip();headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'}
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));endpoint='http://192.168.16.19:18691/v1'
name='osa-qwen3-coder-30b'if service=='baseline'else'osa-qwen3-coder-next'
O=A/('supervisor335-'+service);O.mkdir(exist_ok=False);state={'status':'waiting_for_service','started':time.time()}
def save():
    p=O/'status.tmp';p.write_text(json.dumps(state,indent=2));p.replace(O/'status.json')
def get(url):return opener.open(urllib.request.Request(url,headers=headers),timeout=5)
try:
    save()
    for _ in range(300):
        try:
            with get(endpoint+'/models')as z:models=json.load(z)
            if any(x['id']==name and x['max_model_len']==262144 for x in models['data']):break
        except Exception:pass
        time.sleep(3)
    else:raise TimeoutError('Model readiness exceeded15minutes')
    guard=json.loads((A/f'guard{guard_id}-model-guard.json').read_text())
    compatibility=json.loads((A/f'guard{guard_id}-provider-compatibility.json').read_text())
    assert compatibility['contract_cases_passed']==48
    serving={k:guard[k]for k in ['model_argv','source_sha256','model_hash_manifest_sha256','gpu_uuids','gpu_indices','host','budget','endpoint']}
    serving.update(served_model=name,model_context=262144,compatibility=compatibility,created=time.time(),guard_id=guard_id)
    (A/('serving-'+service+'.json')).write_text(json.dumps(serving,indent=2))
    with get(endpoint.removesuffix('/v1')+'/metrics')as z:(O/'metrics-before.txt').write_bytes(z.read())
    controls=[]
    for n in [16,256]:
        body=json.loads((M/f'provider-protocol-repair055/before-grid/request-{n}.json').read_text());body['model']=name
        request=urllib.request.Request(endpoint+'/chat/completions',headers=headers,data=json.dumps(body).encode())
        with opener.open(request,timeout=120)as z:reply=json.load(z)
        (O/f'contract-request-{n}.json').write_text(json.dumps(body));(O/f'contract-response-{n}.json').write_text(json.dumps(reply))
        controls.append({'max_output':n,'finish_reason':reply['choices'][0]['finish_reason'],**reply['usage']})
    assert controls[0]['finish_reason']=='length'and controls[1]['finish_reason']=='tool_calls',controls
    assert sum(x['total_tokens']for x in controls)<=10000
    (O/'provider-admission.json').write_text(json.dumps({'passed':True,'actual_api_calls':2,'actual_api_tokens':sum(x['total_tokens']for x in controls),'cases':controls},indent=2))
    state.update(status='capability_running',serving=serving);save()
    log=(O/'runner.log').open('ab');c=subprocess.Popen([str(R/'m3a2/native-env026/bin/python'),str(R/'recovery_runner335.py')],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    state['process']={'pid':c.pid,'start_ticks':Path(f'/proc/{c.pid}/stat').read_text().rsplit(')',1)[1].split()[19],'source_sha256':hashlib.sha256((R/'recovery_runner335.py').read_bytes()).hexdigest()};save()
    code=c.wait(timeout=6500)
    with get(endpoint.removesuffix('/v1')+'/metrics')as z:(O/'metrics-after.txt').write_bytes(z.read())
    state.update(status='completed'if code==0 else'failed',exit=code,finished=time.time());save()
except BaseException as error:
    state.update(status='failed',error=type(error).__name__+':'+str(error),finished=time.time());save();raise
finally:(A/'STOP_RECOVERY334').write_text('Supervisor ended; restore original GPU holders.\n')
