"""Task-specific CPU placement; Docker still enforces original CPU/RAM quotas."""
import sys,os
cpu,client,endpoint,*args=sys.argv[1:];assert cpu in {'0','1','2','3'}and client.startswith('/')and endpoint.startswith(('unix://','tcp://127.0.0.1:'));assert args
if args[0]=='run':args=[args[0],'--cpuset-cpus',cpu,*args[1:]]
os.execv(client,[client,'--host',endpoint,*args])
