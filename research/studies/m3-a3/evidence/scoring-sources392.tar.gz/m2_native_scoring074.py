"""Use the same portable scoring implementation shipped to external users."""
from pathlib import Path
import os,sys
R=Path('/physis/users/chenxinyu/operations/opensuperagent-stage1-20261102');M=R/'m2';RT=M/'runtime'
os.environ.update(DOCKER_HOST='tcp://127.0.0.1:28239',DOCKER_TLS_VERIFY='1',DOCKER_CERT_PATH=str(RT/'docker-client-tls-001'),DOCKER_CONFIG=str(RT/'docker-cli-config-001'),PATH=str(RT/'docker-client-001')+':'+os.environ['PATH'])
sys.path.insert(0,str(M/'public-runner074'))
import official_regrade as public
PRE=[str(RT/'docker-client-001/docker'),'--host','tcp://127.0.0.1:28239','--tlsverify','--tlscacert',str(RT/'docker-client-tls-001/ca.pem'),'--tlscert',str(RT/'docker-client-tls-001/cert.pem'),'--tlskey',str(RT/'docker-client-tls-001/key.pem')]
public.configure(M/'official-pro-checkout-001',M/'native-env-harbor-003/bin/harbor',PRE)
replay=public.replay
